// compile order for the UVM testbench (relative to the project root)
sv/apb_if.sv
sv/adc_if.sv
sv/sar_afe_model.sv
sv/timer_adc_sva.sv
tb_uvm/timer_adc_pkg.sv
tb_uvm/tb_top.sv
