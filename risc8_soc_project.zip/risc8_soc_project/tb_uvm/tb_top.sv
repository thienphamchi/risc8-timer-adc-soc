// =====================================================================
//  tb_top.sv - UVM top: clock/reset, DUT, analog model, interfaces, run_test()
//  Choose the test with  +UVM_TESTNAME=tadc_all_test  (or reg / adc_sw / timer /
//  adc_timer / window / fifo / random).  Add +DUMP for tb_top.vcd.
// =====================================================================
`timescale 1ns/1ps
module tb_top;
    import uvm_pkg::*;
    import timer_adc_pkg::*;

    logic clk   = 1'b0;
    logic rst_n = 1'b0;
    always #5 clk = ~clk;                         // 100 MHz

    apb_if aif (.clk(clk), .rst_n(rst_n));
    adc_if cif (.clk(clk));

    timer_adc8_top dut (
        .clk(clk), .rst_n(rst_n),
        .psel(aif.psel), .penable(aif.penable), .pwrite(aif.pwrite),
        .paddr(aif.paddr), .pwdata(aif.pwdata), .prdata(aif.prdata), .pready(aif.pready),
        .irq(aif.irq), .pwm_out(aif.pwm_out),
        .adc_sample(cif.sample), .adc_ch(cif.ch), .adc_dac(cif.dac), .adc_cmp(cif.cmp));

    sar_afe_model afe (.aif(cif));                // pretend analog circuit

    initial begin
        repeat (5) @(posedge clk);
        rst_n = 1'b1;
    end

    initial begin
        uvm_config_db #(virtual apb_if)::set(null, "*", "apb_vif", aif);
        uvm_config_db #(virtual adc_if)::set(null, "*", "adc_vif", cif);
        run_test();
    end

    initial begin
        if ($test$plusargs("DUMP")) begin
            $dumpfile("tb_top.vcd");
            $dumpvars(0, tb_top);
        end
    end
endmodule
