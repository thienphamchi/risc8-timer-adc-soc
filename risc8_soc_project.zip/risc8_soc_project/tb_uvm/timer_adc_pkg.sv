// =====================================================================
//  timer_adc_pkg.sv - UVM 1.2 testbench for the 8-bit Timer + SAR ADC peripheral
//  Vivado xsim:  xvlog -sv -L uvm ...   xelab -L uvm ...   (see scripts/)
//
//    test -> env -> apb_agent (sequencer, driver, monitor)   talks on the register bus
//                -> adc_agent (sets input voltages, monitor)  analog side
//                -> scoreboard (reference model) + 2 coverage collectors
// =====================================================================
`include "uvm_macros.svh"

package timer_adc_pkg;
    import uvm_pkg::*;

    // register numbers (page offsets)
    localparam bit [3:0] R_TMR_CTRL = 4'h0, R_TMR_PRESC = 4'h1, R_TMR_LOAD = 4'h2, R_TMR_CMP = 4'h3,
                         R_TMR_CNT  = 4'h4, R_ADC_CTRL  = 4'h5, R_ADC_SMP  = 4'h6, R_ADC_DIV = 4'h7,
                         R_THR_LO   = 4'h8, R_THR_HI    = 4'h9, R_ADC_DATA = 4'hA, R_ADC_RCH = 4'hB,
                         R_ADC_STAT = 4'hC, R_IRQ_EN    = 4'hD, R_IRQ_STAT = 4'hE, R_ID       = 4'hF;

    // ------------------------------------------------------------------
    //  Transaction items
    // ------------------------------------------------------------------
    class apb_item extends uvm_sequence_item;
        rand bit       write;
        rand bit [3:0] addr;
        rand bit [7:0] wdata;
        bit      [7:0] rdata;
        `uvm_object_utils(apb_item)
        function new(string name = "apb_item");
            super.new(name);
        endfunction
        function string convert2string();
            return $sformatf("%s addr=0x%0h wdata=0x%02h rdata=0x%02h", write ? "WR" : "RD", addr, wdata, rdata);
        endfunction
    endclass

    class adc_conv extends uvm_object;           // one conversion seen by the adc monitor
        bit [1:0] ch;
        int       mv;
        bit [7:0] code;                          // expected result = floor(mv/Vref*256), max 255
        `uvm_object_utils(adc_conv)
        function new(string name = "adc_conv");
            super.new(name);
        endfunction
    endclass

    // ------------------------------------------------------------------
    //  APB agent
    // ------------------------------------------------------------------
    typedef uvm_sequencer #(apb_item) apb_sequencer;

    class apb_driver extends uvm_driver #(apb_item);
        `uvm_component_utils(apb_driver)
        virtual apb_if vif;
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            if (!uvm_config_db #(virtual apb_if)::get(this, "", "apb_vif", vif))
                `uvm_fatal("NOVIF", "apb_vif not set in uvm_config_db")
        endfunction
        task run_phase(uvm_phase phase);
            forever begin
                seq_item_port.get_next_item(req);
                drive(req);
                seq_item_port.item_done();
            end
        endtask
        // psel = penable = 1 for ONE clock, exactly like the CPU's io_cs pulse
        task drive(apb_item t);
            @(posedge vif.clk);
            vif.psel    <= 1'b1;
            vif.penable <= 1'b1;
            vif.pwrite  <= t.write;
            vif.paddr   <= t.addr;
            vif.pwdata  <= t.wdata;
            @(posedge vif.clk);                  // the DUT samples the access on this edge
            t.rdata = vif.prdata;                // read data is valid in the same clock
            vif.psel    <= 1'b0;
            vif.penable <= 1'b0;
            vif.pwrite  <= 1'b0;
        endtask
    endclass

    class apb_monitor extends uvm_monitor;
        `uvm_component_utils(apb_monitor)
        virtual apb_if vif;
        uvm_analysis_port #(apb_item) ap;
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            ap = new("ap", this);
            if (!uvm_config_db #(virtual apb_if)::get(this, "", "apb_vif", vif))
                `uvm_fatal("NOVIF", "apb_vif not set in uvm_config_db")
        endfunction
        task run_phase(uvm_phase phase);
            apb_item t;
            forever begin
                @(posedge vif.clk);
                if (vif.rst_n && vif.psel && vif.penable) begin
                    t = apb_item::type_id::create("mon_item");
                    t.write = vif.pwrite;
                    t.addr  = vif.paddr;
                    t.wdata = vif.pwdata;
                    t.rdata = vif.prdata;
                    ap.write(t);
                end
            end
        endtask
    endclass

    class apb_agent extends uvm_agent;
        `uvm_component_utils(apb_agent)
        apb_sequencer sqr;
        apb_driver    drv;
        apb_monitor   mon;
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            sqr = apb_sequencer::type_id::create("sqr", this);
            drv = apb_driver::type_id::create("drv", this);
            mon = apb_monitor::type_id::create("mon", this);
        endfunction
        function void connect_phase(uvm_phase phase);
            drv.seq_item_port.connect(sqr.seq_item_export);
        endfunction
    endclass

    // one bus access as a sequence (the tests use it through wr()/rd())
    class apb_rw_seq extends uvm_sequence #(apb_item);
        `uvm_object_utils(apb_rw_seq)
        bit       write;
        bit [3:0] addr;
        bit [7:0] wdata;
        bit [7:0] rdata;
        function new(string name = "apb_rw_seq");
            super.new(name);
        endfunction
        task body();
            req = apb_item::type_id::create("req");
            start_item(req);
            req.write = write;
            req.addr  = addr;
            req.wdata = wdata;
            finish_item(req);
            rdata = req.rdata;
        endtask
    endclass

    // ------------------------------------------------------------------
    //  ADC agent: sets the analog input voltages, watches conversions
    // ------------------------------------------------------------------
    class adc_monitor extends uvm_monitor;
        `uvm_component_utils(adc_monitor)
        virtual adc_if vif;
        uvm_analysis_port #(adc_conv) ap;
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            ap = new("ap", this);
            if (!uvm_config_db #(virtual adc_if)::get(this, "", "adc_vif", vif))
                `uvm_fatal("NOVIF", "adc_vif not set in uvm_config_db")
        endfunction
        // the sample/hold freezes the input when 'sample' falls: that is the voltage converted
        task run_phase(uvm_phase phase);
            bit prev;
            adc_conv c;
            int code;
            prev = 1'b0;
            forever begin
                @(posedge vif.clk);
                if (prev && !vif.sample) begin
                    c = adc_conv::type_id::create("conv");
                    c.ch   = vif.ch;
                    c.mv   = vif.vin_mv[vif.ch];
                    code   = (c.mv * 256) / vif.vref_mv;
                    c.code = (code > 255) ? 8'd255 : ((code < 0) ? 8'd0 : code[7:0]);
                    ap.write(c);
                end
                prev = vif.sample;
            end
        endtask
    endclass

    class adc_agent extends uvm_agent;
        `uvm_component_utils(adc_agent)
        virtual adc_if vif;
        adc_monitor mon;
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            mon = adc_monitor::type_id::create("mon", this);
            if (!uvm_config_db #(virtual adc_if)::get(this, "", "adc_vif", vif))
                `uvm_fatal("NOVIF", "adc_vif not set in uvm_config_db")
        endfunction
        function void set_vin(int ch, int mv);   // "analog driver": change a sensor voltage
            vif.vin_mv[ch] = mv;
        endfunction
    endclass

    // ------------------------------------------------------------------
    //  Scoreboard: reference model of the register file and the result FIFO
    // ------------------------------------------------------------------
    `uvm_analysis_imp_decl(_apb)
    `uvm_analysis_imp_decl(_adc)

    class tadc_scoreboard extends uvm_scoreboard;
        `uvm_component_utils(tadc_scoreboard)
        uvm_analysis_imp_apb #(apb_item, tadc_scoreboard) apb_export;
        uvm_analysis_imp_adc #(adc_conv, tadc_scoreboard) adc_export;
        adc_conv  fifo_q [$];                     // model of the 8-entry result FIFO
        bit [7:0] shadow [16];                    // model of the RW registers
        int       n_checks, n_dropped;

        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            apb_export = new("apb_export", this);
            adc_export = new("adc_export", this);
            foreach (shadow[i]) shadow[i] = 8'h00;
            shadow[R_THR_HI] = 8'hFF;             // reset value
        endfunction

        function void write_adc(adc_conv c);      // a conversion finished -> result queued
            if (fifo_q.size() >= 8) n_dropped++;
            else                    fifo_q.push_back(c);
        endfunction

        function void chk_val(string what, bit [7:0] got, bit [7:0] exp);
            n_checks++;
            if (got !== exp)
                `uvm_error("SB", $sformatf("%s: got 0x%02h expected 0x%02h", what, got, exp))
        endfunction

        function void write_apb(apb_item t);
            adc_conv  c;
            bit [7:0] exp;
            bit [3:0] lvl;
            if (t.write) begin
                case (t.addr)
                    R_TMR_CTRL: shadow[t.addr] = t.wdata & 8'h03;
                    R_ADC_CTRL: shadow[t.addr] = t.wdata & 8'h3D;   // START (bit 1) is not stored
                    R_IRQ_EN:   shadow[t.addr] = t.wdata & 8'h1F;
                    R_TMR_PRESC, R_TMR_LOAD, R_TMR_CMP, R_ADC_SMP, R_ADC_DIV, R_THR_LO, R_THR_HI:
                                shadow[t.addr] = t.wdata;
                    default: ;
                endcase
            end else begin
                case (t.addr)
                    R_ADC_DATA: begin
                        exp = 8'h00;
                        if (fifo_q.size() > 0) begin
                            c = fifo_q.pop_front();
                            exp = c.code;
                        end
                        chk_val("ADC_DATA", t.rdata, exp);
                    end
                    R_ADC_RCH: begin
                        exp = 8'h00;
                        if (fifo_q.size() > 0) exp = {1'b1, 5'b0, fifo_q[0].ch};
                        chk_val("ADC_RCH", t.rdata, exp);
                    end
                    R_ADC_STAT: begin
                        if (!t.rdata[6]) begin    // BUSY = 0 -> level / empty / full are predictable
                            lvl = fifo_q.size();
                            exp = {2'b00, (fifo_q.size() == 8), (fifo_q.size() == 0), lvl};
                            chk_val("ADC_STAT", t.rdata & 8'h3F, exp);
                        end
                    end
                    R_ID: chk_val("ID", t.rdata, 8'hA8);
                    R_TMR_CTRL: if (!shadow[R_TMR_CTRL][1]) chk_val("TMR_CTRL", t.rdata, shadow[R_TMR_CTRL]);
                    R_TMR_PRESC, R_TMR_LOAD, R_TMR_CMP, R_ADC_CTRL, R_ADC_SMP, R_ADC_DIV, R_THR_LO, R_THR_HI, R_IRQ_EN:
                        chk_val($sformatf("reg[0x%0h]", t.addr), t.rdata, shadow[t.addr]);
                    default: ;
                endcase
            end
        endfunction

        function void report_phase(uvm_phase phase);
            `uvm_info("SB", $sformatf("%0d register/FIFO checks done, %0d results dropped by the model (FIFO full)",
                                      n_checks, n_dropped), UVM_NONE)
        endfunction
    endclass

    // ------------------------------------------------------------------
    //  Functional coverage
    // ------------------------------------------------------------------
    class apb_cov extends uvm_subscriber #(apb_item);
        `uvm_component_utils(apb_cov)
        apb_item it;
        covergroup cg_apb;
            cp_addr : coverpoint it.addr;
            cp_rw   : coverpoint it.write;
            cx      : cross cp_addr, cp_rw;
        endgroup
        function new(string name, uvm_component parent);
            super.new(name, parent);
            cg_apb = new();
        endfunction
        function void write(apb_item t);
            it = t;
            cg_apb.sample();
        endfunction
    endclass

    class adc_cov extends uvm_subscriber #(adc_conv);
        `uvm_component_utils(adc_cov)
        adc_conv cv;
        covergroup cg_adc;
            cp_ch   : coverpoint cv.ch;
            cp_code : coverpoint cv.code { bins zero = {0}; bins low = {[1:63]}; bins mid = {[64:191]};
                                           bins high = {[192:254]}; bins full = {255}; }
            cx      : cross cp_ch, cp_code;
        endgroup
        function new(string name, uvm_component parent);
            super.new(name, parent);
            cg_adc = new();
        endfunction
        function void write(adc_conv t);
            cv = t;
            cg_adc.sample();
        endfunction
    endclass

    // ------------------------------------------------------------------
    //  Environment
    // ------------------------------------------------------------------
    class tadc_env extends uvm_env;
        `uvm_component_utils(tadc_env)
        apb_agent        apb_agt;
        adc_agent        adc_agt;
        tadc_scoreboard  sb;
        apb_cov          cov_a;
        adc_cov          cov_d;
        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            apb_agt = apb_agent::type_id::create("apb_agt", this);
            adc_agt = adc_agent::type_id::create("adc_agt", this);
            sb      = tadc_scoreboard::type_id::create("sb", this);
            cov_a   = apb_cov::type_id::create("cov_a", this);
            cov_d   = adc_cov::type_id::create("cov_d", this);
        endfunction
        function void connect_phase(uvm_phase phase);
            apb_agt.mon.ap.connect(sb.apb_export);
            apb_agt.mon.ap.connect(cov_a.analysis_export);
            adc_agt.mon.ap.connect(sb.adc_export);
            adc_agt.mon.ap.connect(cov_d.analysis_export);
        endfunction
        function void report_phase(uvm_phase phase);
            `uvm_info("COV", $sformatf("coverage: bus %0.1f %%, ADC %0.1f %%",
                      cov_a.cg_apb.get_inst_coverage(), cov_d.cg_adc.get_inst_coverage()), UVM_NONE)
        endfunction
    endclass

    // ------------------------------------------------------------------
    //  Tests. The stimulus lives in tasks of the base test; each test calls one (or all).
    // ------------------------------------------------------------------
    class tadc_base_test extends uvm_test;
        `uvm_component_utils(tadc_base_test)
        tadc_env       env;
        virtual apb_if avif;

        function new(string name = "tadc_base_test", uvm_component parent = null);
            super.new(name, parent);
        endfunction
        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            env = tadc_env::type_id::create("env", this);
            if (!uvm_config_db #(virtual apb_if)::get(this, "", "apb_vif", avif))
                `uvm_fatal("NOVIF", "apb_vif not set in uvm_config_db")
        endfunction

        // ---- bus helpers ----
        task wr(bit [3:0] a, bit [7:0] d);
            apb_rw_seq s = apb_rw_seq::type_id::create("wr_seq");
            s.write = 1'b1; s.addr = a; s.wdata = d;
            s.start(env.apb_agt.sqr);
        endtask
        task rd(bit [3:0] a, output bit [7:0] d);
            apb_rw_seq s = apb_rw_seq::type_id::create("rd_seq");
            s.write = 1'b0; s.addr = a; s.wdata = 8'h00;
            s.start(env.apb_agt.sqr);
            d = s.rdata;
        endtask
        task wait_idle();                        // poll ADC_STAT.BUSY
            bit [7:0] st;
            int n;
            n = 0;
            do begin
                rd(R_ADC_STAT, st);
                n++;
            end while (st[6] && n < 2000);
            if (n >= 2000) `uvm_error("TEST", "ADC stayed BUSY")
        endtask
        task wait_result();                      // poll ADC_STAT.EMPTY
            bit [7:0] st;
            int n;
            n = 0;
            do begin
                rd(R_ADC_STAT, st);
                n++;
            end while (st[4] && n < 4000);
            if (n >= 4000) `uvm_error("TEST", "no ADC result arrived")
        endtask
        task flush_fifo();                       // pop everything (the scoreboard checks each value)
            bit [7:0] st, d;
            rd(R_ADC_STAT, st);
            while (!st[4]) begin
                rd(R_ADC_DATA, d);
                rd(R_ADC_STAT, st);
            end
        endtask
        task quiesce();                          // timer off, ADC off, FIFO empty, flags cleared
            bit [7:0] d;
            wr(R_TMR_CTRL, 8'h00);
            repeat (8) @(posedge avif.clk);
            wait_idle();
            wr(R_ADC_CTRL, 8'h00);
            wr(R_IRQ_EN, 8'h00);
            flush_fifo();
            wr(R_IRQ_STAT, 8'h1F);
            rd(R_IRQ_STAT, d);
            if (d[4:0] != 5'd0) `uvm_error("TEST", $sformatf("IRQ_STAT not cleared: 0x%02h", d))
        endtask
        task convert(int ch, int mv);            // one software conversion + read RCH and DATA
            bit [7:0] d;
            env.adc_agt.set_vin(ch, mv);
            wr(R_ADC_CTRL, 8'h03 | (ch << 4));
            wait_idle();
            rd(R_ADC_RCH, d);
            if (d != (8'h80 | ch)) `uvm_error("TEST", $sformatf("ADC_RCH 0x%02h for channel %0d", d, ch))
            rd(R_ADC_DATA, d);
        endtask

        // ---- test 1: reset values, read/write, ID ----
        task t_reg();
            bit [7:0] d;
            bit [3:0] regs [9];
            regs = '{R_TMR_PRESC, R_TMR_LOAD, R_TMR_CMP, R_ADC_SMP, R_ADC_DIV, R_THR_LO, R_THR_HI, R_IRQ_EN, R_TMR_CTRL};
            `uvm_info("TEST", "t_reg: reset values and read/write", UVM_LOW)
            foreach (regs[i]) rd(regs[i], d);                    // reset values (scoreboard compares)
            rd(R_ID, d);
            rd(R_ADC_STAT, d);
            foreach (regs[i]) begin
                if (regs[i] == R_TMR_CTRL) begin
                    wr(regs[i], 8'h02); rd(regs[i], d); wr(regs[i], 8'h00); rd(regs[i], d);
                end else begin
                    wr(regs[i], 8'h55); rd(regs[i], d);
                    wr(regs[i], 8'hAA); rd(regs[i], d);
                    wr(regs[i], 8'h00); rd(regs[i], d);
                end
            end
            wr(R_THR_HI, 8'hFF);
            wr(R_ADC_CTRL, 8'h3C); rd(R_ADC_CTRL, d);
            wr(R_ADC_CTRL, 8'h00); rd(R_ADC_CTRL, d);
            quiesce();
        endtask

        // ---- test 2: software-started conversions, corner and random voltages ----
        task t_adc_sw();
            int mvs [9];
            `uvm_info("TEST", "t_adc_sw: software-started conversions", UVM_LOW)
            mvs = '{0, 1, 12, 400, 1111, 1650, 2000, 3299, 3300};
            wr(R_ADC_SMP, 8'd3);
            for (int div = 0; div < 3; div++) begin
                wr(R_ADC_DIV, div);
                for (int ch = 0; ch < 4; ch++)
                    foreach (mvs[i]) convert(ch, mvs[i]);
            end
            repeat (12) convert($urandom_range(3, 0), $urandom_range(3300, 0));
            wr(R_ADC_SMP, 8'd0);
            wr(R_ADC_DIV, 8'd0);
            quiesce();
        endtask

        // ---- test 3: timer period, PWM duty, one-shot, flags ----
        task t_timer();
            int cfg [5][3];
            int presc, load, cmp, period, hi, exp_hi;
            bit [7:0] d;
            `uvm_info("TEST", "t_timer: period, PWM duty, one-shot, flags", UVM_LOW)
            cfg = '{'{0, 9, 3}, '{1, 4, 2}, '{3, 24, 12}, '{0, 7, 0}, '{0, 7, 9}};
            foreach (cfg[i]) begin
                presc = cfg[i][0]; load = cfg[i][1]; cmp = cfg[i][2];
                period = (presc + 1) * (load + 1);
                wr(R_TMR_PRESC, presc); wr(R_TMR_LOAD, load); wr(R_TMR_CMP, cmp);
                wr(R_IRQ_STAT, 8'h1F);
                wr(R_TMR_CTRL, 8'h01);
                repeat (2 * period + 4) @(posedge avif.clk);
                hi = 0;
                repeat (period) begin
                    @(posedge avif.clk);
                    if (avif.pwm_out) hi++;
                end
                exp_hi = ((cmp > load + 1) ? (load + 1) : cmp) * (presc + 1);
                if (hi != exp_hi)
                    `uvm_error("TEST", $sformatf("PWM presc=%0d load=%0d cmp=%0d: %0d high clocks, expected %0d", presc, load, cmp, hi, exp_hi))
                rd(R_IRQ_STAT, d);
                if (!d[0]) `uvm_error("TEST", "TMR_OVF flag not set")
                if (cmp <= load && !d[1]) `uvm_error("TEST", "TMR_CMP flag not set")
                wr(R_TMR_CTRL, 8'h00);
                repeat (4) @(posedge avif.clk);
                if (avif.pwm_out) `uvm_error("TEST", "PWM not low after the timer was disabled")
            end
            // one-shot: stops by itself after the first overflow
            wr(R_TMR_PRESC, 8'd1); wr(R_TMR_LOAD, 8'd4); wr(R_TMR_CMP, 8'd2);
            wr(R_IRQ_STAT, 8'h1F);
            wr(R_TMR_CTRL, 8'h03);
            repeat (40) @(posedge avif.clk);
            rd(R_TMR_CTRL, d);
            if (d[0]) `uvm_error("TEST", "one-shot: EN did not clear by itself")
            rd(R_IRQ_STAT, d);
            if (!d[0]) `uvm_error("TEST", "one-shot: TMR_OVF flag missing")
            wr(R_TMR_CTRL, 8'h00);
            wr(R_TMR_LOAD, 8'd0); wr(R_TMR_CMP, 8'd0); wr(R_TMR_PRESC, 8'd0);
            quiesce();
        endtask

        // ---- test 4: timer-triggered conversions (overflow trigger, compare trigger) ----
        task t_adc_timer();
            bit [7:0] d;
            `uvm_info("TEST", "t_adc_timer: timer-triggered conversions", UVM_LOW)
            wr(R_ADC_SMP, 8'd2); wr(R_ADC_DIV, 8'd0);
            wr(R_TMR_PRESC, 8'd1); wr(R_TMR_LOAD, 8'd29); wr(R_TMR_CMP, 8'd5);
            for (int trig = 1; trig <= 3; trig++) begin
                int ch;
                ch = trig;                                      // channel 1, 2, 3
                wr(R_ADC_CTRL, 8'h01 | (trig << 2) | (ch << 4));
                wr(R_TMR_CTRL, 8'h01);
                repeat (5) begin
                    env.adc_agt.set_vin(ch, $urandom_range(3300, 0));
                    wait_result();
                    rd(R_ADC_RCH, d);
                    if (d != (8'h80 | ch)) `uvm_error("TEST", $sformatf("ADC_RCH 0x%02h, expected channel %0d", d, ch))
                    rd(R_ADC_DATA, d);
                end
                wr(R_TMR_CTRL, 8'h00);
                repeat (6) @(posedge avif.clk);
                wait_idle();
                wr(R_ADC_CTRL, 8'h00);
                flush_fifo();
            end
            wr(R_TMR_PRESC, 8'd0); wr(R_TMR_LOAD, 8'd0); wr(R_TMR_CMP, 8'd0);
            wr(R_ADC_SMP, 8'd0);
            quiesce();
        endtask

        // ---- test 5: window comparator, IRQ flags and the irq pin ----
        task t_window();
            int lo, hi, codes [6];
            int mv;
            bit [7:0] d;
            bit       exp_wd;
            `uvm_info("TEST", "t_window: watchdog flag and irq pin", UVM_LOW)
            lo = 50; hi = 200;
            codes = '{0, 49, 50, 125, 200, 201};
            wr(R_THR_LO, lo); wr(R_THR_HI, hi);
            wr(R_IRQ_EN, 8'h08);                                // only ADC_WD drives the irq pin
            foreach (codes[i]) begin
                mv = (codes[i] * 3300) / 256 + 6;               // inside the 12.9 mV step of that code
                wr(R_IRQ_STAT, 8'h1F);
                convert(0, mv);
                exp_wd = (codes[i] < lo) || (codes[i] > hi);
                rd(R_IRQ_STAT, d);
                if (d[2] !== 1'b1)    `uvm_error("TEST", "ADC_EOC flag missing")
                if (d[3] !== exp_wd)  `uvm_error("TEST", $sformatf("ADC_WD=%0b for code %0d (window %0d..%0d)", d[3], codes[i], lo, hi))
                if (avif.irq !== exp_wd) `uvm_error("TEST", $sformatf("irq pin = %0b, expected %0b", avif.irq, exp_wd))
                wr(R_IRQ_STAT, 8'h0C);
                @(posedge avif.clk);
                if (avif.irq) `uvm_error("TEST", "irq pin still high after W1C")
            end
            wr(R_THR_LO, 8'h00); wr(R_THR_HI, 8'hFF);
            quiesce();
        endtask

        // ---- test 6: FIFO fill, overflow flag, drain ----
        task t_fifo();
            bit [7:0] d;
            `uvm_info("TEST", "t_fifo: fill to 8, overflow, drain", UVM_LOW)
            wr(R_ADC_SMP, 8'd0); wr(R_ADC_DIV, 8'd0);
            wr(R_IRQ_STAT, 8'h1F);
            for (int i = 0; i < 9; i++) begin
                env.adc_agt.set_vin(i % 4, 100 + 300 * i);
                wr(R_ADC_CTRL, 8'h03 | ((i % 4) << 4));
                wait_idle();
            end
            rd(R_ADC_STAT, d);                                  // level 8, FULL (checked by the scoreboard)
            if (d[5:0] !== 6'h28) `uvm_error("TEST", $sformatf("ADC_STAT 0x%02h, expected 0x28 (full)", d))
            rd(R_IRQ_STAT, d);
            if (!d[4]) `uvm_error("TEST", "FIFO_OVR flag not set")
            for (int i = 0; i < 8; i++) begin
                rd(R_ADC_RCH, d);
                rd(R_ADC_DATA, d);
            end
            rd(R_ADC_STAT, d);
            quiesce();
        endtask

        // ---- test 7: random traffic ----
        task t_random();
            bit [7:0] d;
            `uvm_info("TEST", "t_random: random mix", UVM_LOW)
            wr(R_ADC_SMP, $urandom_range(5, 0));
            wr(R_ADC_DIV, $urandom_range(2, 0));
            repeat (60) begin
                case ($urandom_range(5, 0))
                    0, 1: convert($urandom_range(3, 0), $urandom_range(3300, 0));
                    2:    rd(R_ADC_STAT, d);
                    3:    rd(R_IRQ_STAT, d);
                    4:    wr(R_THR_LO, $urandom_range(255, 0));
                    default: begin wr(R_IRQ_STAT, 8'h1F); wr(R_THR_LO, 8'h00); end
                endcase
            end
            wr(R_ADC_SMP, 8'd0); wr(R_ADC_DIV, 8'd0); wr(R_THR_LO, 8'h00);
            quiesce();
        endtask

        virtual task body();
        endtask

        task run_phase(uvm_phase phase);
            phase.raise_objection(this);
            wait (avif.rst_n === 1'b1);
            repeat (3) @(posedge avif.clk);
            body();
            repeat (20) @(posedge avif.clk);
            phase.drop_objection(this);
        endtask

        function void report_phase(uvm_phase phase);
            uvm_report_server svr;
            svr = uvm_report_server::get_server();
            if (svr.get_severity_count(UVM_ERROR) + svr.get_severity_count(UVM_FATAL) == 0)
                `uvm_info("RESULT", "*** UVM TEST PASSED ***", UVM_NONE)
            else
                `uvm_info("RESULT", "*** UVM TEST FAILED ***", UVM_NONE)
        endfunction
    endclass

    class tadc_reg_test       extends tadc_base_test; `uvm_component_utils(tadc_reg_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_reg(); endtask
    endclass
    class tadc_adc_sw_test    extends tadc_base_test; `uvm_component_utils(tadc_adc_sw_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_adc_sw(); endtask
    endclass
    class tadc_timer_test     extends tadc_base_test; `uvm_component_utils(tadc_timer_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_timer(); endtask
    endclass
    class tadc_adc_timer_test extends tadc_base_test; `uvm_component_utils(tadc_adc_timer_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_adc_timer(); endtask
    endclass
    class tadc_window_test    extends tadc_base_test; `uvm_component_utils(tadc_window_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_window(); endtask
    endclass
    class tadc_fifo_test      extends tadc_base_test; `uvm_component_utils(tadc_fifo_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_fifo(); endtask
    endclass
    class tadc_random_test    extends tadc_base_test; `uvm_component_utils(tadc_random_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body(); t_random(); endtask
    endclass
    class tadc_all_test       extends tadc_base_test; `uvm_component_utils(tadc_all_test)
        function new(string name, uvm_component parent); super.new(name, parent); endfunction
        task body();
            t_reg(); t_adc_sw(); t_timer(); t_adc_timer(); t_window(); t_fifo(); t_random();
        endtask
    endclass
endpackage
