// sar_afe_model.sv - behavioural analog front end: mux + comparator (DAC voltage = dac/256*Vref)
// cmp = 1 when Vin(ch) >= DAC voltage  =>  SAR result = floor(Vin / Vref * 256)
module sar_afe_model (adc_if aif);
    assign aif.cmp = ((aif.vin_mv[aif.ch] * 256) >= (int'(aif.dac) * aif.vref_mv));
endmodule
