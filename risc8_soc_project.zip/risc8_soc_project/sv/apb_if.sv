// apb_if.sv - bundle of the APB-style bus wires + the two output pins (simulation only)
interface apb_if (input logic clk, input logic rst_n);
    logic       psel    = 1'b0;
    logic       penable = 1'b0;
    logic       pwrite  = 1'b0;
    logic [3:0] paddr   = 4'h0;
    logic [7:0] pwdata  = 8'h00;
    logic [7:0] prdata;
    logic       pready;
    logic       irq;
    logic       pwm_out;
endinterface
