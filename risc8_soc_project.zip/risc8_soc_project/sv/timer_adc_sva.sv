// =====================================================================
//  timer_adc_sva.sv - 30 SystemVerilog assertions for the Timer/ADC peripheral.
//  Attached to timer_adc8_top with `bind` (no RTL file is edited).
//  Compile only when wanted:  Verilator --assert  /  Vivado xsim (-sv).
//  Failing assertion => $error. A run with "0 errors" = all 30 hold.
// =====================================================================
`define A(NAME, PROP) NAME: assert property (@(posedge clk) disable iff (!rst_n) PROP) \
    else $error("SVA FAIL: %s", `"NAME`");

module timer_adc_sva (
    input logic clk, rst_n,
    // bus
    input logic psel, penable, pwrite, input logic [3:0] paddr, input logic [7:0] prdata, input logic pready,
    // timer
    input logic tmr_en, tmr_oneshot, input logic [7:0] tmr_presc, tmr_load, tmr_cmp, tmr_cnt,
    input logic tmr_ovf, tmr_cmp_match, tmr_stop, pwm_out,
    // adc
    input logic adc_en, adc_busy, adc_sample, adc_done, input logic [1:0] sar_state, input logic [7:0] adc_dac,
    input logic [7:0] result, thr_lo, thr_hi,
    // fifo / flags / irq
    input logic [3:0] fifo_level, input logic fifo_empty, fifo_full, fifo_pop, fifo_ovr,
    input logic [4:0] flags, irq_en, input logic irq
);
    localparam [1:0] IDLE = 2'd0, SAMP = 2'd1, CONV = 2'd2;

    // ---------------- timer ----------------
    `A(a_cnt_le_load,     (tmr_en && $stable(tmr_load)) |-> tmr_cnt <= tmr_load)
    `A(a_ovf_cnt_zero,    tmr_ovf |-> tmr_cnt == 8'd0)
    `A(a_ovf_at_load,     tmr_ovf |-> $past(tmr_cnt) >= $past(tmr_load))
    `A(a_cmp_match,       tmr_cmp_match |-> $past(tmr_cnt) == $past(tmr_cmp))
    `A(a_oneshot_stop,    tmr_stop |-> tmr_oneshot)
    `A(a_stop_after_ovf,  tmr_stop |-> tmr_ovf)
    `A(a_off_cnt_zero,    !tmr_en |=> tmr_cnt == 8'd0)
    `A(a_off_pwm_low,     !tmr_en |=> !pwm_out)
    `A(a_pwm_def,         pwm_out |-> $past(tmr_cnt) < $past(tmr_cmp))
    `A(a_ovf_1clk,        (tmr_ovf && tmr_load != 8'd0) |=> !tmr_ovf)
    // ---------------- ADC controller ----------------
    `A(a_sample_busy,     adc_sample |-> adc_busy)
    `A(a_done_busy,       adc_done |-> adc_busy)
    `A(a_done_1clk,       adc_done |=> !adc_done)
    `A(a_msb_first,       (sar_state == CONV && $past(sar_state) == SAMP) |-> adc_dac == 8'h80)
    `A(a_dac_zero_idle,   (sar_state == IDLE) |-> adc_dac == 8'd0)
    `A(a_dac_zero_sample, adc_sample |-> adc_dac == 8'd0)
    `A(a_disabled_idle,   !adc_en |=> !adc_busy)
    `A(a_sample_only_samp,adc_sample |-> sar_state == SAMP)
    // ---------------- FIFO ----------------
    `A(a_push_level,      (adc_done && !fifo_full && !fifo_pop) |=> fifo_level == $past(fifo_level) + 4'd1)
    `A(a_overflow_drop,   fifo_ovr |-> fifo_full)
    `A(a_level_range,     fifo_level <= 4'd8)
    `A(a_empty_def,       fifo_empty == (fifo_level == 4'd0))
    `A(a_full_def,        fifo_full == (fifo_level == 4'd8))
    `A(a_pop_empty_noop,  (fifo_pop && fifo_empty && !adc_done) |=> fifo_empty)
    // ---------------- flags / irq / bus ----------------
    `A(a_flag_ovf,        tmr_ovf |=> flags[0])
    `A(a_flag_cmp,        tmr_cmp_match |=> flags[1])
    `A(a_flag_eoc,        adc_done |=> flags[2])
    `A(a_flag_wd,         (adc_done && (result < thr_lo || result > thr_hi)) |=> flags[3])
    `A(a_flag_fovr,       fifo_ovr |=> flags[4])
    `A(a_irq_def,         irq == (|(flags & irq_en)))
    `A(a_pop_only_adcdata,fifo_pop |-> (psel && penable && !pwrite && paddr == 4'hA))
    `A(a_unsel_reads_zero,!psel |-> prdata == 8'd0)
    `A(a_id,              (psel && paddr == 4'hF) |-> prdata == 8'hA8)
    `A(a_pready,          pready)
endmodule

// attach the checker to every timer_adc8_top (named connections resolve in the target scope)
bind timer_adc8_top timer_adc_sva u_sva (
    .clk(clk), .rst_n(rst_n), .psel(psel), .penable(penable), .pwrite(pwrite), .paddr(paddr), .prdata(prdata), .pready(pready),
    .tmr_en(tmr_en), .tmr_oneshot(tmr_oneshot), .tmr_presc(tmr_presc), .tmr_load(tmr_load), .tmr_cmp(tmr_cmp), .tmr_cnt(tmr_cnt),
    .tmr_ovf(tmr_ovf), .tmr_cmp_match(tmr_cmp_match), .tmr_stop(tmr_stop), .pwm_out(pwm_out),
    .adc_en(adc_en), .adc_busy(adc_busy), .adc_sample(adc_sample), .adc_done(adc_done), .sar_state(u_sar.state), .adc_dac(adc_dac),
    .result(res), .thr_lo(thr_lo), .thr_hi(thr_hi),
    .fifo_level(fifo_level), .fifo_empty(fifo_empty), .fifo_full(fifo_full), .fifo_pop(fifo_pop), .fifo_ovr(fifo_ovr),
    .flags(u_regs.flags), .irq_en(u_regs.irq_en), .irq(irq)
);
