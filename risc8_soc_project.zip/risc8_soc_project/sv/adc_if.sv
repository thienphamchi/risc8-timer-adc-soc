// adc_if.sv - analog-side wires + the "real world" input voltages (millivolts)
interface adc_if (input logic clk);
    logic       sample;
    logic [1:0] ch;
    logic [7:0] dac;
    logic       cmp;
    int         vref_mv = 3300;
    int         vin_mv [4];                 // set by the UVM adc agent
    initial begin
        vin_mv[0] = 400;  vin_mv[1] = 1111;
        vin_mv[2] = 2000; vin_mv[3] = 3000;
    end
endinterface
