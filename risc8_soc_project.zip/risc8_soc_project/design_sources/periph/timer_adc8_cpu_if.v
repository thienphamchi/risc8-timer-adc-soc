// timer_adc8_cpu_if.v - adapts the CPU's single-cycle I/O port to the peripheral.
//   cs, we, addr[3:0], wdata -> rdata in the SAME clock (cs is 1 clock per LD/ST).
module timer_adc8_cpu_if (
    input  wire       clk,
    input  wire       rst_n,            // active low (connect ~cpu_rst)
    input  wire       cs,
    input  wire       we,
    input  wire [3:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata,
    output wire       irq,
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp,
    output wire       pwm_out
);
    wire pready_unused;
    timer_adc8_top u_top (
        .clk(clk), .rst_n(rst_n),
        .psel(cs), .penable(cs), .pwrite(we),   // setup+access collapsed into one clock
        .paddr(addr), .pwdata(wdata), .prdata(rdata), .pready(pready_unused),
        .irq(irq), .pwm_out(pwm_out),
        .adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp)
    );
endmodule
