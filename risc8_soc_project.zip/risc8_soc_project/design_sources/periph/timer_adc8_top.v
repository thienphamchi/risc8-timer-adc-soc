// timer_adc8_top.v - timer + SAR ADC controller + FIFO + register block (APB-style bus).
module timer_adc8_top (
    input  wire       clk,
    input  wire       rst_n,
    // APB-style slave
    input  wire       psel,
    input  wire       penable,
    input  wire       pwrite,
    input  wire [3:0] paddr,
    input  wire [7:0] pwdata,
    output wire [7:0] prdata,
    output wire       pready,
    // pins
    output wire       irq,
    output wire       pwm_out,
    // analog front end
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp
);
    // register block <-> blocks
    wire        tmr_en, tmr_oneshot, tmr_stop, tmr_ovf, tmr_cmp_match;
    wire [7:0]  tmr_presc, tmr_load, tmr_cmp, tmr_cnt;
    wire        adc_en, adc_start, adc_busy, adc_done;
    wire [1:0]  adc_trig_sel, adc_ch_sel, res_ch;
    wire [7:0]  adc_smp, adc_div, thr_lo, thr_hi, res;
    wire        fifo_pop, fifo_empty, fifo_full, fifo_ovr;
    wire [3:0]  fifo_level;
    wire [9:0]  fifo_dout;

    // ADC start = software START bit OR selected timer event
    wire trig = ((adc_trig_sel == 2'd1) &&  tmr_ovf)
             || ((adc_trig_sel == 2'd2) &&  tmr_cmp_match)
             || ((adc_trig_sel == 2'd3) && (tmr_ovf || tmr_cmp_match));
    wire start = adc_start || trig;

    // window watchdog: result outside [thr_lo, thr_hi]
    wire wd = adc_done && ((res < thr_lo) || (res > thr_hi));

    apb_regs8 u_regs (
        .clk(clk), .rst_n(rst_n),
        .psel(psel), .penable(penable), .pwrite(pwrite),
        .paddr(paddr), .pwdata(pwdata), .prdata(prdata), .pready(pready),
        .tmr_en(tmr_en), .tmr_oneshot(tmr_oneshot),
        .tmr_presc(tmr_presc), .tmr_load(tmr_load), .tmr_cmp(tmr_cmp),
        .tmr_cnt(tmr_cnt), .tmr_stop(tmr_stop),
        .adc_en(adc_en), .adc_start(adc_start), .adc_trig_sel(adc_trig_sel),
        .adc_ch(adc_ch_sel), .adc_smp(adc_smp), .adc_div(adc_div),
        .thr_lo(thr_lo), .thr_hi(thr_hi), .adc_busy(adc_busy),
        .fifo_pop(fifo_pop), .fifo_data(fifo_dout[7:0]), .fifo_ch(fifo_dout[9:8]),
        .fifo_empty(fifo_empty), .fifo_full(fifo_full), .fifo_level(fifo_level),
        .ev_ovf(tmr_ovf), .ev_cmp(tmr_cmp_match), .ev_eoc(adc_done),
        .ev_wd(wd), .ev_fovr(fifo_ovr),
        .irq(irq)
    );

    timer8 u_timer (
        .clk(clk), .rst_n(rst_n),
        .en(tmr_en), .oneshot(tmr_oneshot),
        .presc(tmr_presc), .load(tmr_load), .cmp(tmr_cmp),
        .cnt(tmr_cnt), .ovf(tmr_ovf), .cmp_match(tmr_cmp_match),
        .stop(tmr_stop), .pwm_out(pwm_out)
    );

    sar_adc_ctrl u_sar (
        .clk(clk), .rst_n(rst_n),
        .en(adc_en), .start(start), .ch_sel(adc_ch_sel),
        .smp(adc_smp), .div(adc_div),
        .adc_ch(adc_ch), .adc_sample(adc_sample), .adc_dac(adc_dac), .adc_cmp(adc_cmp),
        .busy(adc_busy), .done(adc_done), .result(res), .result_ch(res_ch)
    );

    sync_fifo #(.WIDTH(10), .AW(3)) u_fifo (
        .clk(clk), .rst_n(rst_n),
        .push(adc_done), .din({res_ch, res}),
        .pop(fifo_pop), .dout(fifo_dout),
        .empty(fifo_empty), .full(fifo_full), .level(fifo_level),
        .overflow(fifo_ovr)
    );
endmodule
