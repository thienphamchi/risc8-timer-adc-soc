// sync_fifo.v - small synchronous FIFO, first-word-fall-through read.
// dout always shows the oldest entry (0 when empty). pop removes it at the clock edge.
// Push while full (and no pop) is dropped and flagged on `overflow`.
module sync_fifo #(
    parameter WIDTH = 10,
    parameter AW    = 3                 // DEPTH = 2**AW = 8
) (
    input  wire             clk,
    input  wire             rst_n,      // async, active low
    input  wire             push,
    input  wire [WIDTH-1:0] din,
    input  wire             pop,
    output wire [WIDTH-1:0] dout,
    output wire             empty,
    output wire             full,
    output wire [AW:0]      level,
    output wire             overflow    // combinational strobe: push dropped this clock
);
    localparam DEPTH = (1 << AW);

    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [AW-1:0]    wr_ptr, rd_ptr;
    reg [AW:0]      count;

    assign empty    = (count == 0);
    assign full     = (count == DEPTH);
    assign level    = count;
    assign dout     = empty ? {WIDTH{1'b0}} : mem[rd_ptr];

    wire do_pop  = pop  && !empty;
    wire do_push = push && (!full || do_pop);
    assign overflow = push && full && !do_pop;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= {AW{1'b0}};
            rd_ptr <= {AW{1'b0}};
            count  <= {(AW+1){1'b0}};
        end else begin
            if (do_push) begin
                mem[wr_ptr] <= din;
                wr_ptr      <= wr_ptr + 1'b1;
            end
            if (do_pop)
                rd_ptr <= rd_ptr + 1'b1;
            case ({do_push, do_pop})
                2'b10:   count <= count + 1'b1;
                2'b01:   count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end
endmodule
