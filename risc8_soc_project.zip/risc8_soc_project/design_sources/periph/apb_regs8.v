// apb_regs8.v - register file + IRQ flags for the Timer/ADC peripheral.
// Simple APB-style slave: an access is (psel && penable); read data is
// combinational from paddr, so a CPU load gets prdata in the same clock.
// Read side effect: reading ADC_DATA (0xA) pops the FIFO once per access.
//
//  0 TMR_CTRL  RW [0] EN [1] ONESHOT
//  1 TMR_PRESC RW tick every PRESC+1 clocks
//  2 TMR_LOAD  RW period = LOAD+1 ticks
//  3 TMR_CMP   RW compare / PWM duty
//  4 TMR_CNT   RO
//  5 ADC_CTRL  RW [0] EN [1] START (write 1, self-clearing, reads 0) [3:2] TRIG_SEL [5:4] CH
//                 TRIG_SEL: 0 software only, 1 timer overflow, 2 timer compare, 3 either
//  6 ADC_SMP   RW sample window - 1
//  7 ADC_DIV   RW ADC clock divider - 1
//  8 ADC_THR_LO RW window low   (reset 0x00)
//  9 ADC_THR_HI RW window high  (reset 0xFF)
//  A ADC_DATA  RO oldest result, read pops FIFO
//  B ADC_RCH   RO [7] VALID [1:0] CH of oldest result, no pop
//  C ADC_STAT  RO [3:0] LEVEL [4] EMPTY [5] FULL [6] BUSY
//  D IRQ_EN    RW flag enables
//  E IRQ_STAT  W1C [0] TMR_OVF [1] TMR_CMP [2] ADC_EOC [3] ADC_WD [4] FIFO_OVR
//  F ID        RO 0xA8
module apb_regs8 (
    input  wire       clk,
    input  wire       rst_n,
    // bus
    input  wire       psel,
    input  wire       penable,
    input  wire       pwrite,
    input  wire [3:0] paddr,
    input  wire [7:0] pwdata,
    output reg  [7:0] prdata,
    output wire       pready,
    // timer
    output reg        tmr_en,
    output reg        tmr_oneshot,
    output reg  [7:0] tmr_presc,
    output reg  [7:0] tmr_load,
    output reg  [7:0] tmr_cmp,
    input  wire [7:0] tmr_cnt,
    input  wire       tmr_stop,         // one-shot finished -> clear EN
    // adc
    output reg        adc_en,
    output reg        adc_start,        // 1-clock pulse, one clock after the write
    output reg  [1:0] adc_trig_sel,
    output reg  [1:0] adc_ch,
    output reg  [7:0] adc_smp,
    output reg  [7:0] adc_div,
    output reg  [7:0] thr_lo,
    output reg  [7:0] thr_hi,
    input  wire       adc_busy,
    // fifo
    output wire       fifo_pop,
    input  wire [7:0] fifo_data,
    input  wire [1:0] fifo_ch,
    input  wire       fifo_empty,
    input  wire       fifo_full,
    input  wire [3:0] fifo_level,
    // event strobes (set a flag at the next clock edge)
    input  wire       ev_ovf,
    input  wire       ev_cmp,
    input  wire       ev_eoc,
    input  wire       ev_wd,
    input  wire       ev_fovr,
    output wire       irq
);
    localparam [7:0] ID_VALUE = 8'hA8;

    assign pready = 1'b1;

    wire access = psel && penable;
    wire wr     = access &&  pwrite;
    wire rd     = access && !pwrite;

    reg [4:0] irq_en;
    reg [4:0] flags;

    assign fifo_pop = rd && (paddr == 4'hA);
    assign irq      = |(flags & irq_en);

    // ---------------- read mux (combinational) ----------------
    always @* begin
        prdata = 8'h00;
        if (psel) begin
            case (paddr)
                4'h0: prdata = {6'b0, tmr_oneshot, tmr_en};
                4'h1: prdata = tmr_presc;
                4'h2: prdata = tmr_load;
                4'h3: prdata = tmr_cmp;
                4'h4: prdata = tmr_cnt;
                4'h5: prdata = {2'b0, adc_ch, adc_trig_sel, 1'b0, adc_en};
                4'h6: prdata = adc_smp;
                4'h7: prdata = adc_div;
                4'h8: prdata = thr_lo;
                4'h9: prdata = thr_hi;
                4'hA: prdata = fifo_data;
                4'hB: prdata = {~fifo_empty, 5'b0, fifo_ch};
                4'hC: prdata = {1'b0, adc_busy, fifo_full, fifo_empty, fifo_level};
                4'hD: prdata = {3'b0, irq_en};
                4'hE: prdata = {3'b0, flags};
                4'hF: prdata = ID_VALUE;
            endcase
        end
    end

    // ---------------- writes ----------------
    wire [4:0] w1c = (wr && paddr == 4'hE) ? pwdata[4:0] : 5'b0;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tmr_en       <= 1'b0;
            tmr_oneshot  <= 1'b0;
            tmr_presc    <= 8'd0;
            tmr_load     <= 8'd0;
            tmr_cmp      <= 8'd0;
            adc_en       <= 1'b0;
            adc_start    <= 1'b0;
            adc_trig_sel <= 2'd0;
            adc_ch       <= 2'd0;
            adc_smp      <= 8'd0;
            adc_div      <= 8'd0;
            thr_lo       <= 8'h00;
            thr_hi       <= 8'hFF;
            irq_en       <= 5'd0;
            flags        <= 5'd0;
        end else begin
            adc_start <= 1'b0;

            // hardware clear of EN (one-shot), software write below wins
            if (tmr_stop)
                tmr_en <= 1'b0;

            if (wr) begin
                case (paddr)
                    4'h0: begin tmr_en <= pwdata[0]; tmr_oneshot <= pwdata[1]; end
                    4'h1: tmr_presc <= pwdata;
                    4'h2: tmr_load  <= pwdata;
                    4'h3: tmr_cmp   <= pwdata;
                    4'h5: begin
                        adc_en       <= pwdata[0];
                        adc_start    <= pwdata[1];
                        adc_trig_sel <= pwdata[3:2];
                        adc_ch       <= pwdata[5:4];
                    end
                    4'h6: adc_smp <= pwdata;
                    4'h7: adc_div <= pwdata;
                    4'h8: thr_lo  <= pwdata;
                    4'h9: thr_hi  <= pwdata;
                    4'hD: irq_en  <= pwdata[4:0];
                    default: ;
                endcase
            end

            // flags: new event wins over a simultaneous clear
            flags <= (flags & ~w1c) | {ev_fovr, ev_wd, ev_eoc, ev_cmp, ev_ovf};
        end
    end
endmodule
