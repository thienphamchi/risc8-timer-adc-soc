// sar_adc_ctrl.v - 8-bit successive-approximation ADC controller.
// Talks to an external DAC + comparator (analog front end):
//   adc_ch[1:0]  : input channel select (latched at start)
//   adc_sample   : 1 = sample/hold is tracking the input
//   adc_dac[7:0] : trial code sent to the DAC
//   adc_cmp      : 1 when  Vin >= DAC(adc_dac)
// Result = floor(Vin / Vref * 256).
//
// Flow:  IDLE --start--> SAMP (smp+1 ticks) --> CONV (8 ticks, MSB first) --> DONE (1 clock) --> IDLE
// A tick happens every (div+1) clocks. `start` is ignored unless en = 1 and idle.
// Clearing `en` aborts a conversion in progress.
module sar_adc_ctrl (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       en,
    input  wire       start,            // 1-clock pulse
    input  wire [1:0] ch_sel,
    input  wire [7:0] smp,              // sample window - 1 (in ticks)
    input  wire [7:0] div,              // ADC clock divider - 1
    // analog front end
    output reg  [1:0] adc_ch,
    output wire       adc_sample,
    output reg  [7:0] adc_dac,
    input  wire       adc_cmp,
    // status / result
    output wire       busy,
    output wire       done,             // 1 clock, result valid
    output reg  [7:0] result,
    output reg  [1:0] result_ch
);
    localparam [1:0] S_IDLE = 2'd0, S_SAMP = 2'd1, S_CONV = 2'd2, S_DONE = 2'd3;

    reg [1:0] state;
    reg [7:0] div_cnt;
    reg [7:0] smp_cnt;
    reg [2:0] bit_idx;

    assign adc_sample = (state == S_SAMP);
    assign busy       = (state != S_IDLE);
    assign done       = (state == S_DONE);

    wire       tick     = (div_cnt >= div);
    wire [7:0] bit_mask = 8'h01 << bit_idx;
    wire [7:0] kept     = adc_cmp ? adc_dac : (adc_dac & ~bit_mask);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= S_IDLE;
            div_cnt   <= 8'd0;
            smp_cnt   <= 8'd0;
            bit_idx   <= 3'd7;
            adc_ch    <= 2'd0;
            adc_dac   <= 8'd0;
            result    <= 8'd0;
            result_ch <= 2'd0;
        end else if (!en) begin
            state   <= S_IDLE;
            div_cnt <= 8'd0;
            adc_dac <= 8'd0;
        end else begin
            case (state)
                S_IDLE: begin
                    if (start) begin
                        adc_ch  <= ch_sel;
                        smp_cnt <= 8'd0;
                        div_cnt <= 8'd0;
                        adc_dac <= 8'd0;
                        state   <= S_SAMP;
                    end
                end

                S_SAMP: begin
                    if (tick) begin
                        div_cnt <= 8'd0;
                        if (smp_cnt >= smp) begin
                            adc_dac <= 8'h80;           // first trial: MSB
                            bit_idx <= 3'd7;
                            state   <= S_CONV;
                        end else begin
                            smp_cnt <= smp_cnt + 8'd1;
                        end
                    end else begin
                        div_cnt <= div_cnt + 8'd1;
                    end
                end

                S_CONV: begin
                    if (tick) begin
                        div_cnt <= 8'd0;
                        if (bit_idx == 3'd0) begin
                            result    <= kept;
                            result_ch <= adc_ch;
                            adc_dac   <= kept;
                            state     <= S_DONE;
                        end else begin
                            adc_dac <= kept | (bit_mask >> 1);
                            bit_idx <= bit_idx - 3'd1;
                        end
                    end else begin
                        div_cnt <= div_cnt + 8'd1;
                    end
                end

                S_DONE: begin
                    adc_dac <= 8'd0;
                    state   <= S_IDLE;
                end
            endcase
        end
    end
endmodule
