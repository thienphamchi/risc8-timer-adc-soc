// =====================================================================
//  FILE   : design_sources/risc8_soc.v
//  MODULE : risc8_soc   (system top: CPU + 8-bit Timer/ADC peripheral)
// ---------------------------------------------------------------------
//  The CPU reaches the peripheral through a 16-byte I/O page at 0xF0-0xFF.
//    risc8_5stage_core (IO_ENABLE = 1)  --io_cs/we/addr/wdata-->  timer_adc8_cpu_if
//                                       <--------io_rdata--------
//  clk is shared; the CPU reset (active-high) is inverted for the
//  peripheral's rst_n. On a real chip release it through a synchronizer.
//
//  CALLS : risc8_5stage_core (rtl), timer_adc8_cpu_if (design_sources/periph)
// =====================================================================
`timescale 1ns/1ps

module risc8_soc #(
    parameter USE_IMEM_FILE = 1,
    parameter IMEM_FILE     = "soc_demo.hex"
) (
    input  wire       clk,
    input  wire       rst,            // active high
    // CPU debug pins
    output wire       halted,
    output wire [7:0] pc_out,
    output wire [1:0] flags_out,
    output wire       instr_done,
    // peripheral pins
    output wire       irq,
    output wire       pwm_out,
    // analog front end
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp
);
    wire       io_cs, io_we;
    wire [3:0] io_addr;
    wire [7:0] io_wdata, io_rdata;

    // ---- CALL: module risc8_5stage_core from design_sources/risc8_5stage_core.v ----
    risc8_5stage_core #(
        .USE_IMEM_FILE (USE_IMEM_FILE),
        .IMEM_FILE     (IMEM_FILE),
        .IO_ENABLE     (1),
        .IO_PAGE       (4'hF)
    ) u_cpu (
        .clk        (clk),
        .rst        (rst),
        .halted     (halted),
        .pc_out     (pc_out),
        .flags_out  (flags_out),
        .instr_done (instr_done),
        .io_cs      (io_cs),
        .io_we      (io_we),
        .io_addr    (io_addr),
        .io_wdata   (io_wdata),
        .io_rdata   (io_rdata)
    );

    // ---- CALL: module timer_adc8_cpu_if from design_sources/periph/timer_adc8_cpu_if.v ----
    timer_adc8_cpu_if u_tadc (
        .clk        (clk),
        .rst_n      (~rst),           // polarity conversion
        .cs         (io_cs),
        .we         (io_we),
        .addr       (io_addr),
        .wdata      (io_wdata),
        .rdata      (io_rdata),
        .irq        (irq),
        .adc_sample (adc_sample),
        .adc_ch     (adc_ch),
        .adc_dac    (adc_dac),
        .adc_cmp    (adc_cmp),
        .pwm_out    (pwm_out)
    );
endmodule
