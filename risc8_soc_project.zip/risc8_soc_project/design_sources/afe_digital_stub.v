// =====================================================================
//  afe_digital_stub.v - SYNTHESIZABLE stand-in for the analog front end.
//  Lets the whole SoC run on the FPGA with no external DAC/comparator:
//  each channel has a fixed 8-bit "input code"; the comparator answer is
//     adc_cmp = (code[ch] >= adc_dac)         (same as Vin >= DAC voltage)
//  Default codes = the simulation voltages: 0.40 V -> 1F, 1.111 V -> 56,
//  2.0 V -> 9B, 3.0 V -> E8 (Vref 3.3 V). Replace with a real DAC/comparator
//  (or the XADC) when you have external hardware.
// =====================================================================
`timescale 1ns/1ps
module afe_digital_stub #(
    parameter [7:0] CODE0 = 8'h1F,
    parameter [7:0] CODE1 = 8'h56,
    parameter [7:0] CODE2 = 8'h9B,
    parameter [7:0] CODE3 = 8'hE8
) (
    input  wire [1:0] adc_ch,
    input  wire [7:0] adc_dac,
    output wire       adc_cmp
);
    reg [7:0] code;
    always @(*) begin
        case (adc_ch)
            2'd0: code = CODE0;
            2'd1: code = CODE1;
            2'd2: code = CODE2;
            default: code = CODE3;
        endcase
    end
    assign adc_cmp = (code >= adc_dac);
endmodule
