// =====================================================================
//  risc8_fpga_top.v - FPGA top for xa7s100fgga676-1Q (Vivado "Top Module").
//  risc8_soc + synthesizable analog stub => self-contained demo, few pins:
//    clk, rst (active-high button), halted, irq, pwm_out, pc_out, flags_out
//  The firmware (soc_demo.hex) is loaded into imem with $readmemh:
//  ADD soc_demo.hex AS A DESIGN SOURCE in Vivado (see scripts/create_project.tcl).
// =====================================================================
`timescale 1ns/1ps
module risc8_fpga_top (
    input  wire       clk,
    input  wire       rst,
    output wire       halted,
    output wire       instr_done,
    output wire [1:0] flags_out,
    output wire [7:0] pc_out,
    output wire       irq,
    output wire       pwm_out
);
    wire       adc_sample, adc_cmp;
    wire [1:0] adc_ch;
    wire [7:0] adc_dac;

    risc8_soc #(.USE_IMEM_FILE(1), .IMEM_FILE("soc_demo.hex")) u_soc (
        .clk(clk), .rst(rst),
        .halted(halted), .pc_out(pc_out), .flags_out(flags_out), .instr_done(instr_done),
        .irq(irq), .pwm_out(pwm_out),
        .adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp)
    );

    afe_digital_stub u_afe (.adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp));
endmodule
