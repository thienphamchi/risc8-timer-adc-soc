## =====================================================================
##  FILE   : risc8_soc.xdc  -  constraints for risc8_fpga_top (CPU + Timer/ADC)
##  DEVICE : XA7S100-1FGGA676Q  (Vivado part: xa7s100fgga676-1Q)
## ---------------------------------------------------------------------
##  PART 1 is complete: enough for synthesis, implementation and timing.
##  PART 2 (pins) must be filled in from YOUR board schematic (the same
##  situation as the original risc8.xdc). No pins = no bitstream.
## =====================================================================

## PART 1 : clock and configuration
create_clock -name sys_clk -period 10.000 [get_ports clk]
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]

## PART 2 : pins (FILL IN, then remove the leading ## )
## Clock / reset
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports clk]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports rst]      ;# active HIGH button
## CPU debug outputs
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports halted]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports instr_done]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {flags_out[0]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {flags_out[1]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[0]}]   ;# ... up to pc_out[7]
## Peripheral outputs (LED / scope / motor driver)
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports pwm_out]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports irq]

## The analog front end is replaced inside the FPGA by design_sources/afe_digital_stub.v
## (fixed input codes 1F / 56 / 9B / E8), so no analog pins are needed for the demo.
