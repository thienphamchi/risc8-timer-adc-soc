proc run_tb {tb {hex ""}} {
    catch {close_sim -force}
    catch {reset_simulation -simset sim_1 -mode behavioral}
    set_property top $tb [get_filesets sim_1]
    set_property top_lib xil_defaultlib [get_filesets sim_1]
    if {$hex ne ""} {
        set_property generic "HEXFILE=\"$hex\"" [get_filesets sim_1]
    } else {
        set_property generic {} [get_filesets sim_1]
    }
    set_property -name {xsim.simulate.runtime} -value {all} -objects [get_filesets sim_1]
    update_compile_order -fileset sim_1
    launch_simulation
}