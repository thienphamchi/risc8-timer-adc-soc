# Synthesis + implementation + reports (no bitstream: pins are still to be assigned in the xdc).
#   vivado -mode batch -source scripts/run_synth_impl.tcl      (after create_project.tcl)
open_project vivado_proj/risc8_soc.xpr
launch_runs synth_1 -jobs 4; wait_on_run synth_1
open_run synth_1; report_utilization -file synth_utilization.rpt; report_timing_summary -file synth_timing.rpt
launch_runs impl_1 -jobs 4; wait_on_run impl_1
open_run impl_1;  report_utilization -file impl_utilization.rpt;  report_timing_summary -file impl_timing.rpt
puts "Reports written: synth_*.rpt  impl_*.rpt  (check WNS >= 0 and WHS >= 0)"
