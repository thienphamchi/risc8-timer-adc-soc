# =====================================================================
#  create_project.tcl - builds the Vivado project for xa7s100fgga676-1Q
#  Run from the PROJECT ROOT:   vivado -mode batch -source scripts/create_project.tcl
#  or inside Vivado: Tools > Run Tcl Script...   (then open vivado_proj/risc8_soc.xpr)
#  Simulation sets created:  sim_1 = SoC system test   sim_cpu = CPU alone   sim_uvm = UVM
# =====================================================================
set root  [file normalize [pwd]]
set proj  [file join $root vivado_proj]
create_project risc8_soc $proj -part xa7s100fgga676-1Q -force
set_property target_language Verilog [current_project]

# ---- design sources (+ firmware hex read by $readmemh in imem.v) ----
add_files -fileset sources_1 [glob $root/design_sources/*.v $root/design_sources/periph/*.v]
add_files -fileset sources_1 $root/sw/soc_demo.hex
set_property file_type {Memory Initialization Files} [get_files soc_demo.hex]
set_property top risc8_fpga_top [get_filesets sources_1]

# ---- constraints ----
add_files -fileset constrs_1 $root/constraints/risc8_soc.xdc

# ---- sim_1 : SoC system test (22 checks) + assertions ----
add_files -fileset sim_1 [list $root/sim_sources/afe_model.v $root/sim_sources/tb_risc8_soc.v $root/sv/timer_adc_sva.sv]
set_property file_type SystemVerilog [get_files $root/sv/timer_adc_sva.sv]
set_property top tb_risc8_soc [get_filesets sim_1]
# absolute path of the firmware, so xsim finds it whatever its working directory is
set_property generic "HEXFILE=\"$root/sw/soc_demo.hex\"" [get_filesets sim_1]
set_property -name {xsim.simulate.runtime} -value {all} -objects [get_filesets sim_1]

# ---- sim_cpu : the original CPU-only test (built-in program) ----
create_fileset -simset sim_cpu
add_files -fileset sim_cpu $root/sim_sources/tb_risc8_5stage.v
set_property top tb_risc8_5stage [get_filesets sim_cpu]
set_property -name {xsim.simulate.runtime} -value {all} -objects [get_filesets sim_cpu]

# ---- sim_uvm : UVM testbench (Vivado ships UVM 1.2, enabled with -L uvm) ----
create_fileset -simset sim_uvm
set uvm_files [list $root/sv/apb_if.sv $root/sv/adc_if.sv $root/sv/sar_afe_model.sv \
                    $root/sv/timer_adc_sva.sv $root/tb_uvm/timer_adc_pkg.sv $root/tb_uvm/tb_top.sv]
add_files -fileset sim_uvm $uvm_files
foreach f $uvm_files { set_property file_type SystemVerilog [get_files -of_objects [get_filesets sim_uvm] $f] }
set_property top tb_top [get_filesets sim_uvm]
set_property -name {xsim.compile.xvlog.more_options}   -value {-L uvm} -objects [get_filesets sim_uvm]
set_property -name {xsim.elaborate.xelab.more_options} -value {-L uvm} -objects [get_filesets sim_uvm]
set_property -name {xsim.simulate.xsim.more_options}   -value {-testplusarg UVM_TESTNAME=tadc_all_test -testplusarg UVM_VERBOSITY=UVM_LOW} -objects [get_filesets sim_uvm]
set_property -name {xsim.simulate.runtime} -value {all} -objects [get_filesets sim_uvm]

current_fileset -simset [get_filesets sim_1]
puts "Project created: $proj/risc8_soc.xpr"
puts "Switch simulation set:  current_fileset -simset \[get_filesets sim_uvm\]   (or Simulation Settings > Simulation set)"
