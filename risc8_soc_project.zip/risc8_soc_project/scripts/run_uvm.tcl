# ============================================================================
# run_uvm.tcl
#
# Description:
#   Creates the sim_uvm simulation fileset and runs UVM tests using Vivado XSim.
#
# Usage:
#   Run the following commands in the Vivado Tcl Console after opening the project:
#
#     source C:/Users/Acer/Downloads/risc8_soc_project/scripts/run_uvm.tcl
#
#     run_uvm                       ;# Run tadc_all_test with seed 1
#     run_uvm tadc_timer_test       ;# Run a specific test
#     run_uvm tadc_random_test 7    ;# Run a test with a specified seed
#     close_uvm                     ;# Safely close the current simulation
#     list_uvm_tests                ;# Display all available UVM tests
#
# Notes:
#   Place this script in the project's scripts/ directory,
#   or manually update the project root directory below.
# ============================================================================


# ---- Determine the project root directory (parent of scripts/) ----
if {[info exists ::UVM_ROOT]} {
    set ::_uvm_root $::UVM_ROOT
} else {
    set ::_uvm_root [file normalize [file join [file dirname [info script]] ..]]
}

# Uncomment and update the following line if automatic root detection fails:
# set ::_uvm_root C:/Users/Acer/Downloads/risc8_soc_project


# ---- Available UVM tests ----
set ::_uvm_tests {
    tadc_reg_test tadc_adc_sw_test tadc_timer_test tadc_adc_timer_test
    tadc_window_test tadc_fifo_test tadc_random_test tadc_all_test
}


# ---- Display all available UVM tests ----
proc list_uvm_tests {} {
    puts "Available UVM tests: $::_uvm_tests"
}


# ---- Safely close the current simulation ----
proc close_uvm {} {
    catch {close_sim -force}
    puts "UVM: Simulation closed."
}


# ---- Main UVM simulation procedure ----
# Arguments:
#   test : UVM test name (default: tadc_all_test)
#   seed : Random seed    (default: 1)
#
proc run_uvm {{test tadc_all_test} {seed 1}} {

    set root $::_uvm_root

    # Validate the requested test name
    if {[lsearch -exact $::_uvm_tests $test] < 0} {
        puts "ERROR: Unknown UVM test '$test'."
        puts "Available tests: $::_uvm_tests"
        return
    }

    # Check whether a Vivado project is currently open
    if {[catch {current_project}]} {
        puts "ERROR: No Vivado project is currently open."
        puts "Please open the risc8_soc.xpr project first."
        return
    }

    # ---- Verify all required SystemVerilog source files ----
    set uvm_files [list \
        $root/sv/apb_if.sv \
        $root/sv/adc_if.sv \
        $root/sv/sar_afe_model.sv \
        $root/sv/timer_adc_sva.sv \
        $root/tb_uvm/timer_adc_pkg.sv \
        $root/tb_uvm/tb_top.sv]

    foreach f $uvm_files {
        if {![file exists $f]} {
            puts "ERROR: Source file not found: $f"
            puts "Please check the project root directory: $root"
            return
        }
    }

    # ---- Close any running simulation and remove the old fileset ----
    catch {close_sim -force}

    if {[llength [get_filesets -quiet sim_uvm]]} {
        catch {current_fileset -simset [get_filesets sim_1]}
        delete_fileset sim_uvm
    }

    # ---- Create a new UVM simulation fileset ----
    create_fileset -simset sim_uvm

    add_files -fileset sim_uvm $uvm_files

    foreach f [get_files -of_objects [get_filesets sim_uvm]] {
        set_property file_type SystemVerilog $f
    }

    set_property top tb_top [get_filesets sim_uvm]
    set_property top_lib xil_defaultlib [get_filesets sim_uvm]

    # ---- Configure UVM libraries and simulation options ----
    set_property \
        -name {xsim.compile.xvlog.more_options} \
        -value {-L uvm} \
        -objects [get_filesets sim_uvm]

    set_property \
        -name {xsim.elaborate.xelab.more_options} \
        -value {-L uvm -timescale 1ns/1ps} \
        -objects [get_filesets sim_uvm]

    set_property \
        -name {xsim.simulate.xsim.more_options} \
        -value "-testplusarg UVM_TESTNAME=$test -testplusarg UVM_VERBOSITY=UVM_LOW -sv_seed $seed" \
        -objects [get_filesets sim_uvm]

    set_property \
        -name {xsim.simulate.runtime} \
        -value {all} \
        -objects [get_filesets sim_uvm]

    # ---- Update compile order and select the UVM simulation fileset ----
    current_fileset -simset [get_filesets sim_uvm]
    update_compile_order -fileset sim_uvm

    # ---- Launch UVM simulation ----
    puts "-----------------------------------------------------------"
    puts "UVM: Running test '$test' with random seed $seed ..."
    puts "-----------------------------------------------------------"

    launch_simulation -simset sim_uvm

    puts "-----------------------------------------------------------"
    puts "Simulation launched."
    puts "Check the simulation log for:"
    puts "  *** UVM TEST PASSED ***"
    puts "  UVM_ERROR : 0"
    puts "  UVM_FATAL : 0"
    puts ""
    puts "When finished, enter: close_uvm"
    puts "-----------------------------------------------------------"
}


# ---- Script initialization message ----
puts "==========================================================="
puts "UVM simulation script loaded successfully."
puts ""
puts "Available commands:"
puts "  run_uvm ?test? ?seed?  - Run a UVM test"
puts "  list_uvm_tests        - List available UVM tests"
puts "  close_uvm             - Close the current simulation"
puts ""
puts "Project root: $::_uvm_root"
puts "==========================================================="
