#!/usr/bin/env python3
"""asm8.py - assembler for the RISC-8 CPU.   usage: asm8.py in.s out.hex [listing]
Syntax : label:   MNEMONIC operands   ; comment      .equ NAME, value
Regs   : R0..R7          Numbers: 123, 0x7B, 0b1111011, or a .equ name / label
Formats (16 bit):
  R  : op | rd | rs1 | rs2 | 000     ADD SUB AND OR XOR
  R1 : op | rd | rs1 | 000000        SHL SHR LD [rs1] ST [rs1]
  I  : op | rd | 0   | imm8          LDI ADDI
  J  : op | 0000 | addr8             JMP BZ BNZ
  N  : NOP = 0x0000, HLT = 0xF000
"""
import sys, re
OP = dict(NOP=0, ADD=1, SUB=2, AND=3, OR=4, XOR=5, SHL=6, SHR=7, LDI=8, ADDI=9,
          LD=10, ST=11, JMP=12, BZ=13, BNZ=14, HLT=15)

def reg(t):
    m = re.fullmatch(r'R([0-7])', t.strip().upper())
    if not m: raise ValueError('bad register: ' + t)
    return int(m.group(1))

def assemble(src):
    syms, lines, pc = {}, [], 0
    for n, raw in enumerate(src.splitlines(), 1):
        t = raw.split(';')[0].strip()
        if not t: continue
        while ':' in t:                       # one or more labels
            lab, t = t.split(':', 1); syms[lab.strip()] = pc; t = t.strip()
        if not t: continue
        if t.lower().startswith('.equ'):
            name, val = [x.strip() for x in t[4:].split(',', 1)]
            syms[name] = int(val, 0); continue
        lines.append((n, pc, raw.strip(), t)); pc += 1
    if pc > 256: raise SystemExit('program too long: %d words' % pc)
    def num(tok):
        tok = tok.strip()
        v = syms[tok] if tok in syms else int(tok, 0)
        if not -128 <= v <= 255: raise ValueError('immediate out of range: ' + tok)
        return v & 0xFF
    words = [0] * 256; lst = []
    for n, a, raw, t in lines:
        parts = t.split(None, 1); m = parts[0].upper(); ops = parts[1] if len(parts) > 1 else ''
        try:
            if m not in OP: raise ValueError('unknown mnemonic ' + m)
            o = OP[m]; w = o << 12
            if m in ('NOP', 'HLT'): pass
            elif m in ('ADD', 'SUB', 'AND', 'OR', 'XOR'):
                rd, r1, r2 = [reg(x) for x in ops.split(',')]; w |= rd << 9 | r1 << 6 | r2 << 3
            elif m in ('SHL', 'SHR'):
                rd, r1 = [reg(x) for x in ops.split(',')]; w |= rd << 9 | r1 << 6
            elif m in ('LD', 'ST'):
                rd, mem = [x.strip() for x in ops.split(',', 1)]
                r1 = reg(mem.strip('[] ')); w |= reg(rd) << 9 | r1 << 6
            elif m in ('LDI', 'ADDI'):
                rd, imm = ops.split(',', 1); w |= reg(rd) << 9 | num(imm)
            else: w |= num(ops)               # JMP / BZ / BNZ
        except Exception as e:
            raise SystemExit('line %d: %s  (%s)' % (n, e, raw))
        words[a] = w; lst.append('%02X: %04X   %s' % (a, w, raw))
    return words, lst

if __name__ == '__main__':
    if len(sys.argv) < 3: raise SystemExit(__doc__)
    words, lst = assemble(open(sys.argv[1]).read())
    open(sys.argv[2], 'w').write(''.join('%04X\n' % w for w in words))
    if len(sys.argv) > 3: open(sys.argv[3], 'w').write('\n'.join(lst) + '\n')
    print('assembled %d instructions -> %s' % (len(lst), sys.argv[2]))
