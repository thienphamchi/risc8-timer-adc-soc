; =====================================================================
;  soc_demo.s - firmware for the RISC-8 SoC (CPU + 8-bit Timer/ADC)
;  Results are stored in data RAM at 0x80..0x91 (R6 = result pointer).
;  Registers: R7 = I/O pointer, R6 = result pointer, R5 = loop counter,
;             R2 = mask 0x10 (EMPTY bit), R0 stays 0.
;  Analog inputs in simulation: ch0 0.40 V, ch1 1.111 V, ch2 2.0 V, ch3 3.0 V
; =====================================================================
.equ TMR_CTRL, 0xF0
.equ TMR_PRESC,0xF1
.equ TMR_LOAD, 0xF2
.equ TMR_CMP,  0xF3
.equ ADC_CTRL, 0xF5
.equ ADC_SMP,  0xF6
.equ ADC_DIV,  0xF7
.equ ADC_THR_HI,0xF9
.equ ADC_DATA, 0xFA
.equ ADC_RCH,  0xFB
.equ ADC_STAT, 0xFC
.equ IRQ_EN,   0xFD
.equ IRQ_STAT, 0xFE
.equ ID_REG,   0xFF

; ---------------- Part A : read the ID register -> MEM[80] = A8
        LDI  R7, ID_REG
        LD   R1, [R7]
        LDI  R6, 0x80
        ST   R1, [R6]
        LDI  R2, 0x10            ; mask for ADC_STAT.EMPTY
        LDI  R3, 1

; ---------------- Part B : one software conversion on ch1 -> MEM[81],[82]
        LDI  R7, ADC_SMP
        LDI  R1, 3
        ST   R1, [R7]            ; SMP = 3
        LDI  R7, ADC_DIV
        LDI  R1, 0
        ST   R1, [R7]            ; DIV = 0
        LDI  R7, ADC_CTRL
        LDI  R1, 0x13            ; EN | START | CH=1
        ST   R1, [R7]
        LDI  R7, ADC_STAT
waitB:  LD   R1, [R7]
        AND  R1, R1, R2          ; Z = 1 when EMPTY = 0
        BNZ  waitB
        LDI  R7, ADC_RCH
        LD   R1, [R7]            ; 0x81 = valid, ch1 (no pop)
        ADDI R6, 1
        ST   R1, [R6]
        LDI  R7, ADC_DATA
        LD   R1, [R7]            ; 0x56 (pops the FIFO)
        ADDI R6, 1
        ST   R1, [R6]

; ---------------- Part C : timer-triggered conversions on ch2 -> MEM[83..8C]
        LDI  R7, TMR_PRESC
        LDI  R1, 3
        ST   R1, [R7]            ; tick every 4 clocks
        LDI  R7, TMR_LOAD
        LDI  R1, 24
        ST   R1, [R7]            ; 25 ticks = 100 clocks
        LDI  R7, TMR_CMP
        LDI  R1, 12
        ST   R1, [R7]
        LDI  R7, ADC_CTRL
        LDI  R1, 0x25            ; EN | TRIG_SEL=1 (timer overflow) | CH=2
        ST   R1, [R7]
        LDI  R7, TMR_CTRL
        LDI  R1, 1
        ST   R1, [R7]            ; start the timer
        LDI  R5, 4               ; collect 4 samples
nextC:  LDI  R7, ADC_STAT
pollC:  LD   R1, [R7]
        AND  R1, R1, R2
        BNZ  pollC
        LDI  R7, ADC_RCH
        LD   R1, [R7]            ; 0x82 = valid, ch2
        ADDI R6, 1
        ST   R1, [R6]
        LDI  R7, ADC_DATA
        LD   R1, [R7]            ; 0x9B = 2.0 V
        ADDI R6, 1
        ST   R1, [R6]
        ADDI R5, 0xFF            ; R5 = R5 - 1
        BNZ  nextC
        LDI  R7, TMR_CTRL        ; stop timer and ADC
        LDI  R1, 0
        ST   R1, [R7]
        LDI  R7, ADC_CTRL
        ST   R1, [R7]
        LDI  R7, IRQ_STAT
        LD   R1, [R7]            ; OVF | CMP | EOC = 0x07
        ADDI R6, 1
        ST   R1, [R6]
        LDI  R1, 0x04            ; clear EOC (write 1 to clear)
        ST   R1, [R7]
        LD   R1, [R7]            ; OVF | CMP = 0x03
        ADDI R6, 1
        ST   R1, [R6]
        LDI  R1, 0x1F
        ST   R1, [R7]            ; clear every flag

; ---------------- Part D : window watchdog on ch3, irq pin -> MEM[8D],[8E]
        LDI  R7, ADC_THR_HI
        LDI  R1, 100
        ST   R1, [R7]            ; THR_HI = 100
        LDI  R7, IRQ_EN
        LDI  R1, 0x08            ; enable ADC_WD -> irq pin
        ST   R1, [R7]
        LDI  R7, ADC_CTRL
        LDI  R1, 0x33            ; EN | START | CH=3 (3.0 V -> 232 > 100)
        ST   R1, [R7]
        LDI  R7, ADC_STAT
waitD:  LD   R1, [R7]
        AND  R1, R1, R2
        BNZ  waitD
        LDI  R7, IRQ_STAT
        LD   R1, [R7]            ; EOC | WD = 0x0C
        ADDI R6, 1
        ST   R1, [R6]
        LDI  R7, ADC_DATA
        LD   R1, [R7]            ; 0xE8
        ADDI R6, 1
        ST   R1, [R6]
        LDI  R7, IRQ_STAT
        LDI  R1, 0x0C
        ST   R1, [R7]            ; acknowledge -> irq pin falls
        LDI  R7, IRQ_EN
        LDI  R1, 0
        ST   R1, [R7]
        LDI  R7, ADC_THR_HI
        LDI  R1, 0xFF
        ST   R1, [R7]

; ---------------- Part F : queue two results, ALU on an I/O pointer -> MEM[8F..91]
        LDI  R7, ADC_CTRL
        LDI  R1, 0x03            ; EN | START | CH=0
        ST   R1, [R7]
        LDI  R7, ADC_STAT
waitF1: LD   R1, [R7]
        AND  R1, R1, R2
        BNZ  waitF1              ; first result queued
        LDI  R7, ADC_CTRL
        LDI  R1, 0x13            ; EN | START | CH=1
        ST   R1, [R7]
        LDI  R4, 0x4F            ; mask BUSY | LEVEL
        LDI  R3, 2
        LDI  R7, ADC_STAT
waitF2: LD   R1, [R7]
        AND  R1, R1, R4
        SUB  R1, R1, R3          ; Z = 1 when not busy and LEVEL = 2
        BNZ  waitF2
        LDI  R7, ADC_DATA
        ADD  R4, R7, R0          ; ALU op on an I/O address: must NOT pop the FIFO
        LD   R1, [R7]            ; 1st pop = ch0 code 0x1F
        LD   R3, [R4]            ; 2nd pop = ch1 code 0x56 (back-to-back loads)
        ADDI R6, 1
        ST   R1, [R6]
        ADDI R6, 1
        ST   R3, [R6]
        LDI  R7, ADC_STAT
        LD   R1, [R7]            ; EMPTY = 0x10
        ADDI R6, 1
        ST   R1, [R6]

; ---------------- Part E : PWM 30 % on pwm_out, then halt (timer keeps running)
        LDI  R7, TMR_PRESC
        LDI  R1, 0
        ST   R1, [R7]
        LDI  R7, TMR_LOAD
        LDI  R1, 9
        ST   R1, [R7]
        LDI  R7, TMR_CMP
        LDI  R1, 3
        ST   R1, [R7]
        LDI  R7, TMR_CTRL
        LDI  R1, 1
        ST   R1, [R7]
        HLT
