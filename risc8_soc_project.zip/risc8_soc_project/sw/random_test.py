#!/usr/bin/env python3
"""random_test.py N [seed] - random programs: RTL (iverilog, IO_ENABLE = 0) vs iss.py.
Run from the project root:  python3 sw/random_test.py 500"""
import random, subprocess, sys, os, tempfile
sys.path.insert(0, os.path.dirname(__file__))
import iss
N = int(sys.argv[1]) if len(sys.argv) > 1 else 100
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
random.seed(seed)
SRC = ['design_sources/alu.v', 'design_sources/regfile.v', 'design_sources/imem.v', 'design_sources/dmem.v',
       'design_sources/control_unit.v', 'design_sources/hazard_unit.v', 'design_sources/risc8_5stage_core.v',
       'sim_sources/tb_dump.v']
tmp = tempfile.mkdtemp()
subprocess.check_call(['iverilog', '-g2005', '-o', tmp + '/d.vvp'] + SRC)

def gen():
    n = random.randint(15, 60); prog = []
    for pc in range(n):
        k = random.random(); rd, r1, r2 = (random.randrange(8) for _ in range(3))
        if k < 0.40: op = random.choice([1, 2, 3, 4, 5]); w = op << 12 | rd << 9 | r1 << 6 | r2 << 3
        elif k < 0.50: op = random.choice([6, 7]); w = op << 12 | rd << 9 | r1 << 6
        elif k < 0.65: w = 8 << 12 | rd << 9 | random.randrange(256)
        elif k < 0.72: w = 9 << 12 | rd << 9 | random.randrange(256)
        elif k < 0.82: w = 10 << 12 | rd << 9 | r1 << 6
        elif k < 0.92: w = 11 << 12 | rd << 9 | r1 << 6
        else: op = random.choice([12, 13, 14]); w = op << 12 | random.randint(pc + 1, n)   # forward only
        prog.append(w)
    prog.append(0xF000); return prog

ok = 0
for t in range(N):
    p = gen(); words = p + [0] * (256 - len(p))
    R, M, Z, C, _ = iss.run(words)
    open(tmp + '/p.hex', 'w').write(''.join('%04X\n' % w for w in words))
    out = subprocess.run(['vvp', tmp + '/d.vvp', '+prog=' + tmp + '/p.hex'], capture_output=True, text=True).stdout.split('\n')
    d = {l[0]: l[1:].split() for l in out if l and l[0] in 'RFMH'}
    try:
        good = ([int(x, 16) for x in d['R']] == R and [int(x, 16) for x in d['M']] == M
                and [int(x) for x in d['F']] == [Z, C] and d['H'] == ['1'])
    except KeyError: good = False
    if good: ok += 1
    else: print('MISMATCH in program', t, ' (seed %d)' % seed)
print('%d / %d random programs match the golden model' % (ok, N))
sys.exit(0 if ok == N else 1)
