#!/usr/bin/env python3
"""iss.py - instruction-set simulator (golden model) for the RISC-8 CPU.
Architectural behaviour only (no pipeline): used to check the RTL with random programs."""
def run(words, max_steps=5000):
    R = [0] * 8; M = [0] * 256; pc = 0; Z = C = 0; steps = 0
    while steps < max_steps:
        w = words[pc]; op = w >> 12; rd = (w >> 9) & 7; r1 = (w >> 6) & 7; r2 = (w >> 3) & 7; imm = w & 0xFF
        pc = (pc + 1) & 0xFF; steps += 1
        def setf(y, c):
            nonlocal Z, C
            Z = int(y == 0); C = c
        if op == 0: pass
        elif op == 1: t = R[r1] + R[r2]; R[rd] = t & 255; setf(R[rd], t >> 8)
        elif op == 2: t = R[r1] - R[r2]; R[rd] = t & 255; setf(R[rd], int(t < 0))
        elif op == 3: R[rd] = R[r1] & R[r2]; setf(R[rd], 0)
        elif op == 4: R[rd] = R[r1] | R[r2]; setf(R[rd], 0)
        elif op == 5: R[rd] = R[r1] ^ R[r2]; setf(R[rd], 0)
        elif op == 6: a = R[r1]; R[rd] = (a << 1) & 255; setf(R[rd], a >> 7)
        elif op == 7: a = R[r1]; R[rd] = a >> 1; setf(R[rd], a & 1)
        elif op == 8: R[rd] = imm
        elif op == 9: t = R[rd] + imm; R[rd] = t & 255; setf(R[rd], t >> 8)
        elif op == 10: R[rd] = M[R[r1]]
        elif op == 11: M[R[r1]] = R[rd]
        elif op == 12: pc = imm
        elif op == 13:
            if Z: pc = imm
        elif op == 14:
            if not Z: pc = imm
        elif op == 15: break
    return R, M, Z, C, steps
