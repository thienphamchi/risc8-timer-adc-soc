// =====================================================================
//  tb_risc8_soc.v - system testbench: CPU + Timer/ADC + analog model.
//  Runs sw/soc_demo.hex, checks RAM[0x80..0x91], the irq pin and the PWM
//  duty (22 checks), writes io_trace.csv (one line per peripheral access).
//  Run from the project root (soc_demo.hex is read from the current dir).
// =====================================================================
`timescale 1ns/1ps
module tb_risc8_soc #(parameter HEXFILE = "soc_demo.hex");
    reg clk = 0, rst = 1;
    wire halted, instr_done, irq, pwm_out, adc_sample, adc_cmp;
    wire [7:0] pc_out, adc_dac; wire [1:0] flags_out, adc_ch;

    risc8_soc #(.USE_IMEM_FILE(1), .IMEM_FILE(HEXFILE)) dut (
        .clk(clk), .rst(rst), .halted(halted), .pc_out(pc_out), .flags_out(flags_out),
        .instr_done(instr_done), .irq(irq), .pwm_out(pwm_out),
        .adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp));
    afe_model afe (.adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp));

    initial forever #5 clk = ~clk;

    integer cycles = 0, io_acc = 0, errors = 0, checks = 0, fd;
    reg irq_seen_high = 0, irq_seen_low_after = 0;
    always @(posedge clk) if (!rst) begin
        cycles <= cycles + 1;
        if (dut.io_cs) begin
            io_acc <= io_acc + 1;
            $fdisplay(fd, "%0d,%02h,%0d,%1h,%02h,%02h", cycles, dut.u_cpu.pc_out, dut.io_we, dut.io_addr, dut.io_wdata, dut.io_rdata);
        end
        if (irq) irq_seen_high <= 1;
        if (irq_seen_high && !irq && !halted) irq_seen_low_after <= 1;
    end

    task chk(input [8*60-1:0] name, input [7:0] got, input [7:0] exp); begin
        checks = checks + 1;
        if (got !== exp) begin errors = errors + 1; $display("FAIL: %0s  got %h  expected %h", name, got, exp); end
        else $display("PASS: %0s = %h", name, got);
    end endtask
    task chk1(input [8*60-1:0] name, input ok); begin
        checks = checks + 1;
        if (!ok) begin errors = errors + 1; $display("FAIL: %0s", name); end else $display("PASS: %0s", name);
    end endtask

    integer i, hi;
    reg [7:0] exp [0:17];
    initial begin
        fd = $fopen("io_trace.csv", "w"); $fdisplay(fd, "cycle,pc,we,addr,wdata,rdata");
        exp[0]=8'hA8; exp[1]=8'h81; exp[2]=8'h56;
        exp[3]=8'h82; exp[4]=8'h9B; exp[5]=8'h82; exp[6]=8'h9B; exp[7]=8'h82; exp[8]=8'h9B; exp[9]=8'h82; exp[10]=8'h9B;
        exp[11]=8'h07; exp[12]=8'h03; exp[13]=8'h0C; exp[14]=8'hE8; exp[15]=8'h1F; exp[16]=8'h56; exp[17]=8'h10;
        repeat (3) @(negedge clk); rst = 0;
        i = 0;
        while (!halted && i < 5000) begin @(negedge clk); i = i + 1; end
        $display("CPU halted after %0d cycles, %0d I/O accesses", cycles, io_acc);
        chk1("CPU halted (no timeout)", halted === 1'b1);
        for (i = 0; i < 18; i = i + 1) begin
            checks = checks + 1;
            if (dut.u_cpu.u_dmem.mem[8'h80 + i] !== exp[i]) begin errors = errors + 1;
                $display("FAIL: MEM[%02h] = %h, expected %h", 8'h80 + i, dut.u_cpu.u_dmem.mem[8'h80 + i], exp[i]); end
            else $display("PASS: MEM[%02h] = %h", 8'h80 + i, exp[i]);
        end
        chk1("irq pin went high during part D and was cleared", irq_seen_high && irq_seen_low_after);
        chk1("irq pin low at the end", irq === 1'b0);
        repeat (30) @(negedge clk);
        hi = 0;
        for (i = 0; i < 100; i = i + 1) begin @(negedge clk); if (pwm_out) hi = hi + 1; end
        chk1("PWM high for 30 of 100 clocks", hi == 30);
        $fclose(fd);
        $display("--------------------------------------------------");
        if (errors == 0) $display("*** SOC TEST PASSED *** (%0d checks)", checks);
        else             $display("*** SOC TEST FAILED *** (%0d of %0d checks failed)", errors, checks);
        $display("--------------------------------------------------");
        $finish;
    end
    initial begin #200000 $display("TIMEOUT"); $finish; end
    initial if ($test$plusargs("DUMP")) begin $dumpfile("risc8_soc.vcd"); $dumpvars(0, tb_risc8_soc); end
endmodule
