// tb_dump.v - runs a program given by +prog=<file.hex> on the bare CPU
// (IO_ENABLE = 0) and prints the final state in the format of sw/random_test.py.
`timescale 1ns/1ps
module tb_dump;
    reg clk = 0, rst = 1; wire halted, instr_done; wire [7:0] pc; wire [1:0] flags;
    risc8_5stage_core #(.USE_IMEM_FILE(1), .IMEM_FILE(""), .IO_ENABLE(0)) dut (
        .clk(clk), .rst(rst), .halted(halted), .pc_out(pc), .flags_out(flags), .instr_done(instr_done),
        .io_cs(), .io_we(), .io_addr(), .io_wdata(), .io_rdata(8'h00));
    always #5 clk = ~clk;
    reg [1023:0] fname; integer i, n;
    initial begin
        if (!$value$plusargs("prog=%s", fname)) begin $display("need +prog=file"); $finish; end
        #1 $readmemh(fname, dut.u_imem.g_file.rom);
        #20 rst = 0;
        n = 0; while (!halted && n < 20000) begin @(posedge clk); n = n + 1; end
        $write("R"); for (i = 0; i < 8; i = i + 1) $write(" %02x", dut.u_rf.r[i]); $write("\n");
        $write("F %0d %0d\n", flags[1], flags[0]);
        $write("M"); for (i = 0; i < 256; i = i + 1) $write(" %02x", dut.u_dmem.mem[i]); $write("\n");
        $write("H %0d\n", halted);
        $finish;
    end
endmodule
